import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { onCall, HttpsError } from 'firebase-functions/v2/https';

initializeApp();
const db = getFirestore();
const requireUser = (uid?: string) => { if (!uid) throw new HttpsError('unauthenticated', 'Login required'); return uid; };
const requireAdmin = (auth: any) => { if (!auth?.token?.admin) throw new HttpsError('permission-denied', 'Admin only'); };

export const followHost = onCall(async (req) => {
  const userId = requireUser(req.auth?.uid);
  const hostId = String(req.data?.hostId || '');
  if (!hostId || hostId === userId) throw new HttpsError('invalid-argument', 'Valid hostId required');
  const hostRef = db.doc(`hosts/${hostId}`);
  const userRef = db.doc(`users/${userId}/following/${hostId}`);
  const followerRef = db.doc(`hosts/${hostId}/followers/${userId}`);
  await db.runTransaction(async tx => {
    const host = await tx.get(hostRef);
    if (!host.exists || host.get('status') !== 'approved') throw new HttpsError('failed-precondition', 'Host is not approved');
    const already = await tx.get(userRef);
    if (!already.exists) {
      tx.set(userRef, { hostId, createdAt: FieldValue.serverTimestamp() });
      tx.set(followerRef, { userId, createdAt: FieldValue.serverTimestamp() });
      tx.update(hostRef, { followersCount: FieldValue.increment(1) });
    }
  });
  return { ok: true, following: true };
});

export const unfollowHost = onCall(async (req) => {
  const userId = requireUser(req.auth?.uid);
  const hostId = String(req.data?.hostId || '');
  if (!hostId) throw new HttpsError('invalid-argument', 'hostId required');
  const hostRef = db.doc(`hosts/${hostId}`);
  const userRef = db.doc(`users/${userId}/following/${hostId}`);
  const followerRef = db.doc(`hosts/${hostId}/followers/${userId}`);
  await db.runTransaction(async tx => {
    const followed = await tx.get(userRef);
    if (followed.exists) {
      tx.delete(userRef); tx.delete(followerRef);
      const host = await tx.get(hostRef);
      if (host.exists) tx.update(hostRef, { followersCount: FieldValue.increment(-1) });
    }
  });
  return { ok: true, following: false };
});

export const reviewHostVerification = onCall(async (req) => {
  requireUser(req.auth?.uid); requireAdmin(req.auth);
  const hostId = String(req.data?.hostId || '');
  const decision = String(req.data?.decision || '');
  const note = String(req.data?.note || '').slice(0, 500);
  if (!hostId || !['approved','rejected'].includes(decision)) throw new HttpsError('invalid-argument', 'Invalid host or decision');
  const hostRef = db.doc(`hosts/${hostId}`);
  const submissionRef = db.doc(`verificationSubmissions/${hostId}`);
  await db.runTransaction(async tx => {
    const submission = await tx.get(submissionRef);
    if (!submission.exists || submission.get('status') !== 'pending') throw new HttpsError('failed-precondition', 'No pending verification');
    tx.set(hostRef, { status: decision, isVerified: decision === 'approved', reviewedAt: FieldValue.serverTimestamp() }, { merge: true });
    tx.update(submissionRef, { status: decision, adminNote: note, reviewedAt: FieldValue.serverTimestamp() });
  });
  return { ok: true, status: decision };
});
