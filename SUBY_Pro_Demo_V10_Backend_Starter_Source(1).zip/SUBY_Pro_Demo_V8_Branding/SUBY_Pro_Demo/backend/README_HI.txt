SUBY V10 BACKEND STARTER (Firebase)

इस पैकेज में Firebase backend का शुरुआती ढाँचा है:
- Firestore rules: user/host/admin data access और Follow relationships
- Storage rules: verification media निजी; केवल संबंधित Host और Admin पढ़ सकें
- Cloud Functions: followHost, unfollowHost, reviewHostVerification

महत्वपूर्ण: यह backend starter है, deployed/connected service नहीं। V9 का Android demo अभी local JavaScript data पर चलता है। इसे live करने के लिए Firebase project बनाना, Android app में Firebase Auth/Firestore/Storage SDK जोड़ना, Firebase config लगाना, Admin custom claim सुरक्षित तरीके से देना, media upload metadata लिखना, FCM notifications और client UI को callable functions से जोड़ना बाकी है।

सेटअप:
1. Firebase Console में नया project बनाएं और billing/region/privacy आवश्यकताएँ जाँचें।
2. Firebase CLI install करके इस firebase folder में `firebase login` और `firebase use --add` चलाएँ।
3. `cd functions && npm install` चलाएँ।
4. `firebase deploy --only firestore:rules,storage,functions` चलाएँ।
5. Admin custom claim केवल trusted server से set करें; ऐप से admin role कभी set न होने दें।
6. Android client में Firebase Authentication, Firestore और Storage integrate करें।

सुरक्षा नोट:
- वास्तविक Aadhaar/ID document अभी collect न करें जब तक lawful KYC provider, consent, retention/deletion और access policy तय न हो।
- Verification selfie/video public profile में कभी न दिखाएँ। Upload path verification/{uid}/... रखें।
- Storage rules size/type checks देती हैं, पर production में video duration, malware/content checks, rate limits और abuse review भी जोड़ें।
- Admin claim सेट करने के लिए कोई public endpoint नहीं दिया गया है।
- यह code security review और emulator tests के बाद ही production में deploy करें।

वर्तमान Android demo और यह backend starter अभी आपस में wired नहीं हैं। कोई असली login, upload, follow sync या push notification इस ZIP से अपने-आप शुरू नहीं होगा।
