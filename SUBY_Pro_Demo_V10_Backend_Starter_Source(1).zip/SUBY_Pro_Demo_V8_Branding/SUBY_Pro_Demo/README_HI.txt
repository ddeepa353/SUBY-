SUBY PRO DEMO — Android Studio Source

इस संस्करण में:
- बेहतर SUBY ब्रांड UI और Home screen
- ₹500 demo membership (एक बार activate)
- Audio ₹5/min और Video ₹10/min simulated timer
- Demo wallet, recent activity और 50/50 split ledger
- Host registration mock form और 18+ confirmation
- Admin dashboard, demo verification queue
- Location sharing default OFF; demo में असली location access नहीं
- Android wrapper में FLAG_SECURE (सामान्य screenshots को रोकने का best-effort उपाय)

अभी उपलब्ध नहीं:
- असली OTP/login, server/database, live audio/video calls, beauty/HD camera filters
- असली payment gateway, subscription auto-renewal, host payouts
- असली KYC/document verification, admin authentication, location tracking
- APK binary — इस वातावरण में Android SDK/Gradle build tools मौजूद नहीं हैं।

APK build:
1. Android Studio में यह folder खोलें।
2. Android SDK 35 और compatible Gradle/Android Gradle Plugin डाउनलोड/install करें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. Debug APK: app/build/outputs/apk/debug/app-debug.apk

सुरक्षा:
FLAG_SECURE सामान्य screenshot/recording को रोकने का प्रयास करता है; दूसरे फोन से रिकॉर्डिंग रोकने की गारंटी नहीं देता।
Demo data local JavaScript state में है और app बंद होने पर reset हो जाता है।
Production release से पहले server-side security, privacy/consent, age checks, moderation, payment compliance और legal review आवश्यक हैं।


SUBY PRO DEMO V2 में जोड़ा गया:
- शुरुआत में User / Host / Admin role selection.
- Host role में registration form.
- Admin demo PIN: 2468 (यह सुरक्षा वाला असली login नहीं है).
- Demo host applications admin queue में दिखते हैं; Approve / Reject buttons केवल local demo state बदलते हैं.
- Change role से role selector वापस खुलता है.

ध्यान दें:
यह अब भी SOURCE PROJECT है, APK नहीं। Demo में वास्तविक OTP, database/server, live audio/video,
payment gateway, KYC verification, payouts या production security नहीं हैं। फोन/ब्राउज़र बंद करने पर
डेमो आवेदन और कमाई का डेटा मिट सकता है। असली लॉन्च से पहले backend और security आवश्यक हैं.


SUBY V4 Recharge Bonus Update:
- Monthly plans: ₹99 (5% tier recharge bonus), ₹299 (10%), ₹599 (15%).
- Subscriber recharge: amount + tier bonus + additional 10%.
- Additional 10% is recorded as a deduction from the host-share ledger, as requested.
- Tier bonus is recorded separately as a SUBY-funded demo promotion.
- Example: ₹100 recharge on ₹299 plan => ₹100 + ₹10 tier bonus + ₹10 extra = ₹120 wallet credit;
  ₹10 extra is debited from host share.
- This is prototype math only. Before production, approve a sustainable host payout policy, terms,
  accounting treatment, refunds, taxes, payment-gateway fees, and ensure host earnings never become
  negative without transparent contractual rules. Recharge wallet credits are not real money here.
- APK has not been compiled; this is Android Studio source code.


SUBY V5 Gift Store Update:
- Added 20 romantic/couple-themed Gift Store options.
- Price values use the agreed price list: ₹10, ₹20, ₹30, ₹40, ₹50, ₹60, ₹70, ₹80,
  ₹90, ₹100, ₹150, ₹200, ₹300, ₹500, ₹1,000, ₹2,000. Some prices repeat for distinct gifts.
- Users can choose Demo Host A or Demo Host B and send gifts from demo wallet.
- Demo gift revenue is split 50% Host / 50% SUBY.
- Gift visuals are emoji placeholders; custom illustrated gift artwork can replace these later.
- No real payments, server persistence, or live host settlement is connected.
- This is Android Studio source code, not a compiled APK.


SUBY V6 Live + Gift Celebration Update:
- Added Live tab with host selection, demo Live start/end, live gift activity and live-only earnings display.
- Added Host IDs @SUBY001 / @SUBY002 and demo sender ID @USER001.
- Gifts priced ₹1,000 and above trigger a bright celebration ticker showing sender name/ID,
  recipient host name/ID and gift name/value. Ticker is global in the demo UI.
- High-value gift events are added to the Live Gift Activity feed; the selected live host's
  live earnings increase by the demo host share when the gift is sent during that host's live.
- The ticker and feed are local demo-only. To show them to all users/hosts in real time,
  production needs backend event broadcasting (WebSocket/realtime database) and user privacy controls.
- Live camera broadcasting is NOT connected. Need a live-stream SDK/service, host camera permissions,
  moderation, reconnect handling and server-side gift event delivery.
- Existing HD Beauty Studio remains demo controls only; actual live camera filter requires SDK/beauty engine.
- This is Android Studio source, not a compiled APK.


SUBY V7 User-Selected Settings:
- App display name: SUBY.
- Host Live approval mode: automatic self-start after the host has been approved/verified by Admin.
- Live format: Video Live only; Audio Live is not included.
- SUBY UPI ID was provided in chat but is intentionally NOT embedded in the downloadable source or public UI.
  Add payout destination only in a secure, private production admin configuration after payment-provider
  onboarding. Do not place UPI credentials/IDs in public source code.
- The Live screen remains simulated; no real video broadcast, KYC, payment, or payout is connected.
- This is Android Studio source, not a compiled APK.


SUBY V8 Branding:
- Added SUBY vector logo at app/src/main/assets/suby_logo.svg.
- Added Android adaptive launcher icon resources and manifest icon reference.
- Updated app header branding.
- Logo/icon are editable vector assets.
- This remains a source project, not a compiled APK.
- Production video live/beauty SDK and payment gateway still require selecting a provider,
  creating merchant/developer accounts, server credentials and integrating backend services.

SUBY V9 Follow + Host Photo/Video Verification Demo:
- Host application में selfie photo और छोटा verification video चुनने के inputs जोड़े गए.
- Host को 18+ confirmation और media-review consent देना होगा.
- Android WebView में file picker support जोड़ा गया ताकि gallery से image/video चुनी जा सके.
- Admin Verification Queue में चुनी गई selfie/video preview, host details और Approve/Reject demo actions दिखते हैं.
- Files केवल current local demo session की memory में रहती हैं; server पर upload नहीं होतीं और app refresh/close पर मिट सकती हैं.
- Media limits: photo 8 MB, video 25 MB; production में server-side validation, malware scanning, encrypted storage, strict admin access, retention/deletion controls जरूरी हैं.
- Selfie/video अकेले age या identity proof नहीं हैं. Production KYC/age verification और consent/legal review अलग से चाहिए.
- Follow system इस V9 package में शामिल नहीं किया गया है; यह release host media verification update है.
- यह Android Studio source है, APK नहीं. Live camera streaming, real payments, server/database और actual KYC अभी connected नहीं हैं.
- User Home पर Demo Host A/B को Follow/Unfollow कर सकता है; Following list और demo follower count दिखते हैं.
- Follow किए गए demo host के Live start पर local demo alert आता है. वास्तविक push notification और cross-device follower counts के लिए backend + push notification service चाहिए.

SUBY V9 Follow + Host Photo/Video Verification (combined update):
- User Home screen पर Demo Host A/B को Follow/Unfollow कर सकता है.
- Following list और demo follower count दिखते हैं.
- Follow किए गए host के Live start होने पर local demo alert आता है.
- Host application में selfie photo और verification video अनिवार्य हैं.
- Host 18+ confirmation और verification media review consent देती है.
- Admin Verification Queue में submitted photo/video previews देखकर Approve/Reject demo action कर सकता है.
- Android WebView file chooser gallery से image/video चुनने देता है.
- ये सभी counts, applications और media केवल local demo memory में रहते हैं; app बंद/refresh होने पर reset हो सकते हैं.
- Real multi-user follow graph, server media upload, push notifications, encrypted storage, real age/identity KYC और admin authentication अभी connected नहीं हैं.
- Media policy: photo 8 MB तक और video 25 MB तक; production में server-side checks, secure retention/deletion, restricted admin access और consent withdrawal जरूरी हैं.
- यह Android Studio source project है, compiled APK नहीं.

SUBY V10 BACKEND STARTER:
- Added backend/firebase Firestore and Storage security-rule starter.
- Added callable Cloud Functions for follow/unfollow and admin verification review.
- Backend is NOT deployed and is NOT yet connected to Android demo. Firebase project credentials/configuration and Android SDK integration are still required.
- See backend/README_HI.txt for setup and security notes.
